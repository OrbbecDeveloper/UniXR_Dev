
#pragma once
#ifdef RGBD2VR_EXPORTS
#define RGBD2VR_API __declspec(dllexport)
#else
#define RGBD2VR_API __declspec(dllimport)
#endif
#include <opencv2/opencv.hpp>

#define M_PI 3.1415926

extern "C" RGBD2VR_API int RGBD2VR_V1303_BkGlnd(ushort * Depdata, uchar * RGBdata, uchar * MaskPtr, int width, int height, double DBack, /*double k,*/ int isRGBFill, double CameraF,
	uchar * ImgLPtr, uchar * ImgRPtr, uchar * ImgOutPtr, bool backTag, uchar * backImg, uchar * bUse, double PD = 60.0, double eyeShift = 0.0);

