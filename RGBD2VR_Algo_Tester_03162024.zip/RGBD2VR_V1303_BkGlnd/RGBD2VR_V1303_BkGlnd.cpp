#include "pch.h"
#include <math.h>
#include "RGBD2VR_V1303_BkGlnd.h"

int RGBD2VR_V1303_BkGlnd(ushort* Depdata, uchar* RGBdata, uchar* MaskPtr, int width, int height, double DBack, /*double k, */int isRGBFill, double CameraF,
	uchar* ImgLPtr, uchar* ImgRPtr, uchar* ImgOutPtr, bool backTag, uchar* backImg, uchar* bUse, double PD, double eyeShift)
{
	// DBack is the max distance;
	// CameraF original 350;
	// k left right ratio; default = 0.5
	int FWin = 1; // hole filling window size. 0 means no filling
	double cx = 535.0 / 1024 * width; //optical center of the depth camera
	double d = 10.0; // distance between VR screento eye;
	double EyeAngle = 90 * M_PI / 180.0; // Horizontal FoV of Oculus screen
	double CameraAngle = 75 * M_PI / 180.0; // Horizontal FoV of the camera which is used to take the depth
	double Baseline = PD; // distance between two eyes
	double WL = d * tan(EyeAngle / 2); // Oculus screen width
	double scenThread = 200;
	int bdSize = 5;
	//if (k > 1)
	//	k = k / 10;
	double k = eyeShift / PD + 0.5;
	double f;
	if (CameraF == 0)
		f = width / 2 / tan(CameraAngle / 2);
	else
		f = CameraF;

	//target image pixel taken tag
	cv::Mat ImgTagL = cv::Mat::zeros(height, width, CV_16U);
	cv::Mat ImgTagR = cv::Mat::zeros(height, width, CV_16U);
	ushort* ImgTagLPtr = reinterpret_cast<ushort*>(ImgTagL.data);
	ushort* ImgTagRPtr = reinterpret_cast<ushort*>(ImgTagR.data);
	//save the move target I
	cv::Mat MvImgL = cv::Mat::zeros(height, width, CV_16U);
	cv::Mat MvImgR = cv::Mat::zeros(height, width, CV_16U);
	ushort* MvImgLPtr = reinterpret_cast<ushort*>(MvImgL.data);
	ushort* MvImgRPtr = reinterpret_cast<ushort*>(MvImgR.data);
	memcpy(ImgOutPtr, backImg, width * height * sizeof(ushort) * 3);

	int fTag = 0;
	int indexR = 0;
	int index = 0;
	double fDepStart;
	ushort DepPixel = 0;
	uchar r = 0, g = 0, b = 0;
	int  tempTag = 0;
	// left image ��ͼ�ƶ�pixel
	for (int j = 0; j < height; j++) {
		indexR = j * width;
		tempTag = 0;
		fDepStart = 0;
		//for (int i = width - 1; i >= 0; i--) {
		for (int i = bdSize; i < width - bdSize; i++) {
			if (i == 1011 && j == 405)
			{
				i = i;
			}
			index = indexR + i;//current working pixel index on original images
			if (MaskPtr[index] == 0)
			{
			
				tempTag++;

				if (!fTag)
				{
					if (Depdata[index - 1] == 0 && Depdata[index] > 0 && tempTag > 3)
					{

						int depDif = int(fDepStart) - Depdata[index];
						if (fDepStart == 0)
						{
							fDepStart = Depdata[index];
							fTag = 1;
						}
						else if (abs(depDif) < 200)
						{
							fTag = 1;
						}
						bUse[index * 3 + 2] = 255;
						//tempTag = 0;
					}
					else if ((Depdata[index - 1] - Depdata[index]) > 200 && tempTag > 3 && Depdata[index] > 0)
					{
						fTag = 1;
						fDepStart = Depdata[index];
						bUse[index * 3 + 2] = 255;
						//tempTag = 0;
					}
				}
				//if (fTag)
				else 
				{
					if ((Depdata[index] - Depdata[index-1]) > 200 || Depdata[index] == 0)
					{
						tempTag = 0;
						fTag = 0;
						bUse[index * 3 + 1] = 255;
					}
				}

				DepPixel = Depdata[index];
				double D = DepPixel;
				r = RGBdata[index * 3 + 0];
				g = RGBdata[index * 3 + 1];
				b = RGBdata[index * 3 + 2];
				if (fTag)
				{
					
					double xI_l = d / D * (D * (i - cx) / f + Baseline * (1 - k));
					int I_l = static_cast<int>((1 + xI_l / WL) * width / 2);
					if (I_l > 0 && I_l < width) 
					{
						int indexFill = j * width + I_l;
						int indexFill3 = indexFill * 3;

						int indexO = indexR * 3 * 2 + I_l * 3;
						ImgOutPtr[indexO] = r;
						ImgOutPtr[indexO + 1] = g;
						ImgOutPtr[indexO + 2] = b;

						MvImgLPtr[index] = I_l;   //��ԭʼ��Ȳ�ɫͼͬ������ŵ�ǰpixel���ƶ���������

	#ifdef CheckLnR
						ImgLPtr[indexFill3 + 0] = r;
						ImgLPtr[indexFill3 + 1] = g;
						ImgLPtr[indexFill3 + 2] = b;
	#endif // CheckLnR

						ImgTagLPtr[indexFill] = i;	//�������ɫͼͬ����i��ʾ���pixel�Ѿ���pixel��ס����סpixel��ԭʼ������i��

						bUse[index * 3 + 0] = 255;
						//bUse[index * 3 + 1] = 255;
						//bUse[index * 3 + 2] = 255;

					}
				}
			}
		}
	}
	//��ͼ���
	int fillCount1 = 0;
	int fillCount2 = 0;
	int fillCount3 = 0;

	for (int j = 0; j < height; j++) {
		int indexRow = j * width;
		//for (int i = width - 1; i >= 0; i--) {
		int FillTagL = 0;
		int FillTagR = 0;
		int depTagL = 0;
		int depTagR = 0;
		int FillStartTag = 0;
		int FillTag = 0;
		for (int i = 5; i < width-5; i++) {
			//if (i == 654 && j == 378)
			//{
			//	i = i;
			//}
			index = indexRow + i;					//current working pixel index on original images
			if (bUse[index * 3 + 0] == 255/*MaskPtr[index] == 0*/)
			{


				if (FillTag == 0 && ImgTagLPtr[index] > 0 && ImgTagLPtr[index + 1] == 0)
				{
					FillTagL = index;							//�����Ľ��ͼRGB�±꣬���
					depTagL = ImgTagLPtr[FillTagL] + indexRow; //��������RGBԭͼ�±꣬���
					FillTag = 1;
				}
				if (FillTag == 1 && ImgTagLPtr[index] == 0 && ImgTagLPtr[index + 1] > 0)
				{
					FillTagR = index + 1;							//�����Ľ��ͼRGB�±꣬�Ҳ�
					depTagR = ImgTagLPtr[FillTagR] + indexRow;//��������RGBԭͼ�±꣬�Ҳ�
					FillTag = 2;
				}
				if (FillTag == 2)
				{
					FillTag = 0;
					{
						if (Depdata[depTagL] - 300 > Depdata[depTagR])
						{
							FillTagL -= 4;
							depTagL -= 5;
						}
						else if (Depdata[depTagL] + 300 < Depdata[depTagR])
						{
							FillTagR += 2;
							depTagR += 2;
						}

						
						for (int fi = FillTagL + 1; fi < FillTagR; fi++)
						{
							int findex = (fi + indexRow) * 3;
							double K = abs(double(depTagR) - double(depTagL)) / (double(FillTagR) - double(FillTagL));

							double rgbIndex = double(depTagL) + K * (double(fi) - double(FillTagL));
							int FL, FR;
							double ratio;
							ratio = rgbIndex - floorf(rgbIndex);
							FL = static_cast<int>(floor(rgbIndex));
							FR = static_cast<int>(ceil(rgbIndex));
							ImgOutPtr[findex + 0] = RGBdata[(FL) * 3 + 0] * (1 - ratio) + RGBdata[(FR) * 3 + 0] * (ratio);
							ImgOutPtr[findex + 1] = RGBdata[(FL) * 3 + 1] * (1 - ratio) + RGBdata[(FR) * 3 + 1] * (ratio);
							ImgOutPtr[findex + 2] = RGBdata[(FL) * 3 + 2] * (1 - ratio) + RGBdata[(FR) * 3 + 2] * (ratio);
							fillCount3++;

						}
					}

				}
			}
		}
	}

	//right image
	for (int j = 0; j < height; j++) {
		indexR = j * width;
		for (int i = width - 1; i >= 0; i--) {
			//for (int i = 0; i < width; i++) {
			if (j == 338 && i == 1001)
			{
				i = i;
			}
			index = indexR + i;					//current working pixel index on original images
			DepPixel = Depdata[index];
			double D = DepPixel;
			r = RGBdata[index * 3 + 0];
			g = RGBdata[index * 3 + 1];
			b = RGBdata[index * 3 + 2];
			if (MaskPtr[index] == 0 && D > 0) {
				double xI_r = d / D * (D * (i - cx) / f - Baseline * k);
				int I_r = static_cast<int>((1 + xI_r / WL) * width / 2);
				if (I_r > 0 && I_r < width) {
					int indexFill = indexR + I_r;
					int indexFill3 = indexFill * 3;

					int indexO = (indexR * 2 + I_r + width) * 3;
					ImgOutPtr[indexO + 0] = r;
					ImgOutPtr[indexO + 1] = g;
					ImgOutPtr[indexO + 2] = b;
#ifdef CheckLnR
					ImgRPtr[indexFill3 + 0] = r;
					ImgRPtr[indexFill3 + 1] = g;
					ImgRPtr[indexFill3 + 2] = b;
#endif // CheckLnR
					MvImgRPtr[index] = I_r;//��ԭʼ��Ȳ�ɫͼͬ������ŵ�ǰpixel���ƶ���������

					ImgTagRPtr[indexFill] = i;//�������ɫͼͬ����i��ʾ���pixel�Ѿ���pixel��ס����סpixel��ԭʼ������i��
				}

			}
		}
	}
	for (int j = 0; j < height; j++) {
		int indexRow = j * width;
		//for (int i = width - 1; i >= 0; i--) {
		int FillTagL = 0;
		int FillTagR = 0;
		int depTagL = 0;
		int depTagR = 0;
		int FillStartTag = 0;
		int FillTag = 0;
		for (int i = 0; i < width; i++)
		{
			index = indexRow + i;					//current working pixel index on original images
			if (MaskPtr[index] == 0)
			{
				if (FillTag == 0 && ImgTagRPtr[index] > 0 && ImgTagRPtr[index + 1] == 0)
				{
					FillTagL = index;
					depTagL = ImgTagRPtr[FillTagL] + indexRow;
					FillTag = 1;
				}
				if (FillTag == 1 && ImgTagRPtr[index] == 0 && ImgTagRPtr[index + 1] > 0)
				{
					FillTagR = index + 1;
					depTagR = ImgTagRPtr[FillTagR] + indexRow;
					FillTag = 2;
				}
				if (FillTag == 2)
				{
					FillTag = 0;
					if (Depdata[depTagL] - 300 > Depdata[depTagR])
					{
						FillTagL -= 2;
						depTagL -= 2;
					}
					else if (Depdata[depTagL] + 300 < Depdata[depTagR])
					{
						FillTagR += 4;
						depTagR += 4;
					}


					for (int fi = FillTagL + 1; fi < FillTagR; fi++)
					{
						int findex = (fi + indexRow + width) * 3;
						double K = abs(double(depTagR) - double(depTagL)) / (double(FillTagR) - double(FillTagL));

						//int rgbIndex = depTagL + K * (fi - FillTagL);
						//ImgOutPtr[findex + 0] = RGBdata[(rgbIndex) * 3 + 0];
						//ImgOutPtr[findex + 1] = RGBdata[(rgbIndex) * 3 + 1];
						//ImgOutPtr[findex + 2] = RGBdata[(rgbIndex) * 3 + 2];
						double rgbIndex = double(depTagL) + K * (double(fi) - double(FillTagL));
						int FL, FR;
						double ratio;
						ratio = rgbIndex - floorf(rgbIndex);
						FL = static_cast<int>(floor(rgbIndex));
						FR = static_cast<int>(ceil(rgbIndex));
						ImgOutPtr[findex + 0] = RGBdata[(FL) * 3 + 0] * (1 - ratio) + RGBdata[(FR) * 3 + 0] * (ratio);
						ImgOutPtr[findex + 1] = RGBdata[(FL) * 3 + 1] * (1 - ratio) + RGBdata[(FR) * 3 + 1] * (ratio);
						ImgOutPtr[findex + 2] = RGBdata[(FL) * 3 + 2] * (1 - ratio) + RGBdata[(FR) * 3 + 2] * (ratio);


						fillCount3++;

					}


				}
			}
		}
	}

	return 1;
}
